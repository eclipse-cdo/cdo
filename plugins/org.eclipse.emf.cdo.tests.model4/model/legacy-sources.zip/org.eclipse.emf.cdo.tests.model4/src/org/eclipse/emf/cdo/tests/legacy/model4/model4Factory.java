/**
 * <copyright>
 * </copyright>
 *
 * $Id: model4Factory.java,v 1.2 2008/09/18 12:56:49 estepper Exp $
 */
package org.eclipse.emf.cdo.tests.legacy.model4;

import org.eclipse.emf.cdo.tests.model4.ContainedElementNoOpposite;
import org.eclipse.emf.cdo.tests.model4.GenRefMultiContained;
import org.eclipse.emf.cdo.tests.model4.GenRefMultiNonContained;
import org.eclipse.emf.cdo.tests.model4.GenRefSingleContained;
import org.eclipse.emf.cdo.tests.model4.GenRefSingleNonContained;
import org.eclipse.emf.cdo.tests.model4.ImplContainedElementNPL;
import org.eclipse.emf.cdo.tests.model4.ImplMultiRefContainedElement;
import org.eclipse.emf.cdo.tests.model4.ImplMultiRefContainer;
import org.eclipse.emf.cdo.tests.model4.ImplMultiRefContainerNPL;
import org.eclipse.emf.cdo.tests.model4.ImplMultiRefNonContainedElement;
import org.eclipse.emf.cdo.tests.model4.ImplMultiRefNonContainer;
import org.eclipse.emf.cdo.tests.model4.ImplMultiRefNonContainerNPL;
import org.eclipse.emf.cdo.tests.model4.ImplSingleRefContainedElement;
import org.eclipse.emf.cdo.tests.model4.ImplSingleRefContainer;
import org.eclipse.emf.cdo.tests.model4.ImplSingleRefContainerNPL;
import org.eclipse.emf.cdo.tests.model4.ImplSingleRefNonContainedElement;
import org.eclipse.emf.cdo.tests.model4.ImplSingleRefNonContainer;
import org.eclipse.emf.cdo.tests.model4.ImplSingleRefNonContainerNPL;
import org.eclipse.emf.cdo.tests.model4.MultiContainedElement;
import org.eclipse.emf.cdo.tests.model4.MultiNonContainedElement;
import org.eclipse.emf.cdo.tests.model4.RefMultiContained;
import org.eclipse.emf.cdo.tests.model4.RefMultiContainedNPL;
import org.eclipse.emf.cdo.tests.model4.RefMultiNonContained;
import org.eclipse.emf.cdo.tests.model4.RefMultiNonContainedNPL;
import org.eclipse.emf.cdo.tests.model4.RefSingleContained;
import org.eclipse.emf.cdo.tests.model4.RefSingleContainedNPL;
import org.eclipse.emf.cdo.tests.model4.RefSingleNonContained;
import org.eclipse.emf.cdo.tests.model4.RefSingleNonContainedNPL;
import org.eclipse.emf.cdo.tests.model4.SingleContainedElement;
import org.eclipse.emf.cdo.tests.model4.SingleNonContainedElement;

/**
 * <!-- begin-user-doc --> The <b>Factory</b> for the model. It provides a create method for each non-abstract class of
 * the model. <!-- end-user-doc -->
 * 
 * @see org.eclipse.emf.cdo.tests.legacy.model4.model4Package
 * @generated NOT
 */
public interface model4Factory extends org.eclipse.emf.cdo.tests.model4.model4Factory
{
  /**
   * The singleton instance of the factory. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  model4Factory eINSTANCE = org.eclipse.emf.cdo.tests.legacy.model4.impl.model4FactoryImpl.init();

  /**
   * Returns a new object of class '<em>Ref Single Contained</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Ref Single Contained</em>'.
   * @generated
   */
  RefSingleContained createRefSingleContained();

  /**
   * Returns a new object of class '<em>Single Contained Element</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Single Contained Element</em>'.
   * @generated
   */
  SingleContainedElement createSingleContainedElement();

  /**
   * Returns a new object of class '<em>Ref Single Non Contained</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Ref Single Non Contained</em>'.
   * @generated
   */
  RefSingleNonContained createRefSingleNonContained();

  /**
   * Returns a new object of class '<em>Single Non Contained Element</em>'. <!-- begin-user-doc --> <!-- end-user-doc
   * -->
   * 
   * @return a new object of class '<em>Single Non Contained Element</em>'.
   * @generated
   */
  SingleNonContainedElement createSingleNonContainedElement();

  /**
   * Returns a new object of class '<em>Ref Multi Contained</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Ref Multi Contained</em>'.
   * @generated
   */
  RefMultiContained createRefMultiContained();

  /**
   * Returns a new object of class '<em>Multi Contained Element</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Multi Contained Element</em>'.
   * @generated
   */
  MultiContainedElement createMultiContainedElement();

  /**
   * Returns a new object of class '<em>Ref Multi Non Contained</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Ref Multi Non Contained</em>'.
   * @generated
   */
  RefMultiNonContained createRefMultiNonContained();

  /**
   * Returns a new object of class '<em>Multi Non Contained Element</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Multi Non Contained Element</em>'.
   * @generated
   */
  MultiNonContainedElement createMultiNonContainedElement();

  /**
   * Returns a new object of class '<em>Ref Single Contained NPL</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Ref Single Contained NPL</em>'.
   * @generated
   */
  RefSingleContainedNPL createRefSingleContainedNPL();

  /**
   * Returns a new object of class '<em>Ref Single Non Contained NPL</em>'. <!-- begin-user-doc --> <!-- end-user-doc
   * -->
   * 
   * @return a new object of class '<em>Ref Single Non Contained NPL</em>'.
   * @generated
   */
  RefSingleNonContainedNPL createRefSingleNonContainedNPL();

  /**
   * Returns a new object of class '<em>Ref Multi Contained NPL</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Ref Multi Contained NPL</em>'.
   * @generated
   */
  RefMultiContainedNPL createRefMultiContainedNPL();

  /**
   * Returns a new object of class '<em>Ref Multi Non Contained NPL</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Ref Multi Non Contained NPL</em>'.
   * @generated
   */
  RefMultiNonContainedNPL createRefMultiNonContainedNPL();

  /**
   * Returns a new object of class '<em>Contained Element No Opposite</em>'. <!-- begin-user-doc --> <!-- end-user-doc
   * -->
   * 
   * @return a new object of class '<em>Contained Element No Opposite</em>'.
   * @generated
   */
  ContainedElementNoOpposite createContainedElementNoOpposite();

  /**
   * Returns a new object of class '<em>Gen Ref Single Contained</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Gen Ref Single Contained</em>'.
   * @generated
   */
  GenRefSingleContained createGenRefSingleContained();

  /**
   * Returns a new object of class '<em>Gen Ref Single Non Contained</em>'. <!-- begin-user-doc --> <!-- end-user-doc
   * -->
   * 
   * @return a new object of class '<em>Gen Ref Single Non Contained</em>'.
   * @generated
   */
  GenRefSingleNonContained createGenRefSingleNonContained();

  /**
   * Returns a new object of class '<em>Gen Ref Multi Contained</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Gen Ref Multi Contained</em>'.
   * @generated
   */
  GenRefMultiContained createGenRefMultiContained();

  /**
   * Returns a new object of class '<em>Gen Ref Multi Non Contained</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Gen Ref Multi Non Contained</em>'.
   * @generated
   */
  GenRefMultiNonContained createGenRefMultiNonContained();

  /**
   * Returns a new object of class '<em>Impl Single Ref Container</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Impl Single Ref Container</em>'.
   * @generated
   */
  ImplSingleRefContainer createImplSingleRefContainer();

  /**
   * Returns a new object of class '<em>Impl Single Ref Contained Element</em>'. <!-- begin-user-doc --> <!--
   * end-user-doc -->
   * 
   * @return a new object of class '<em>Impl Single Ref Contained Element</em>'.
   * @generated
   */
  ImplSingleRefContainedElement createImplSingleRefContainedElement();

  /**
   * Returns a new object of class '<em>Impl Single Ref Non Container</em>'. <!-- begin-user-doc --> <!-- end-user-doc
   * -->
   * 
   * @return a new object of class '<em>Impl Single Ref Non Container</em>'.
   * @generated
   */
  ImplSingleRefNonContainer createImplSingleRefNonContainer();

  /**
   * Returns a new object of class '<em>Impl Single Ref Non Contained Element</em>'. <!-- begin-user-doc --> <!--
   * end-user-doc -->
   * 
   * @return a new object of class '<em>Impl Single Ref Non Contained Element</em>'.
   * @generated
   */
  ImplSingleRefNonContainedElement createImplSingleRefNonContainedElement();

  /**
   * Returns a new object of class '<em>Impl Multi Ref Non Container</em>'. <!-- begin-user-doc --> <!-- end-user-doc
   * -->
   * 
   * @return a new object of class '<em>Impl Multi Ref Non Container</em>'.
   * @generated
   */
  ImplMultiRefNonContainer createImplMultiRefNonContainer();

  /**
   * Returns a new object of class '<em>Impl Multi Ref Non Contained Element</em>'. <!-- begin-user-doc --> <!--
   * end-user-doc -->
   * 
   * @return a new object of class '<em>Impl Multi Ref Non Contained Element</em>'.
   * @generated
   */
  ImplMultiRefNonContainedElement createImplMultiRefNonContainedElement();

  /**
   * Returns a new object of class '<em>Impl Multi Ref Container</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Impl Multi Ref Container</em>'.
   * @generated
   */
  ImplMultiRefContainer createImplMultiRefContainer();

  /**
   * Returns a new object of class '<em>Impl Multi Ref Contained Element</em>'. <!-- begin-user-doc --> <!--
   * end-user-doc -->
   * 
   * @return a new object of class '<em>Impl Multi Ref Contained Element</em>'.
   * @generated
   */
  ImplMultiRefContainedElement createImplMultiRefContainedElement();

  /**
   * Returns a new object of class '<em>Impl Single Ref Container NPL</em>'. <!-- begin-user-doc --> <!-- end-user-doc
   * -->
   * 
   * @return a new object of class '<em>Impl Single Ref Container NPL</em>'.
   * @generated
   */
  ImplSingleRefContainerNPL createImplSingleRefContainerNPL();

  /**
   * Returns a new object of class '<em>Impl Single Ref Non Container NPL</em>'. <!-- begin-user-doc --> <!--
   * end-user-doc -->
   * 
   * @return a new object of class '<em>Impl Single Ref Non Container NPL</em>'.
   * @generated
   */
  ImplSingleRefNonContainerNPL createImplSingleRefNonContainerNPL();

  /**
   * Returns a new object of class '<em>Impl Multi Ref Container NPL</em>'. <!-- begin-user-doc --> <!-- end-user-doc
   * -->
   * 
   * @return a new object of class '<em>Impl Multi Ref Container NPL</em>'.
   * @generated
   */
  ImplMultiRefContainerNPL createImplMultiRefContainerNPL();

  /**
   * Returns a new object of class '<em>Impl Multi Ref Non Container NPL</em>'. <!-- begin-user-doc --> <!--
   * end-user-doc -->
   * 
   * @return a new object of class '<em>Impl Multi Ref Non Container NPL</em>'.
   * @generated
   */
  ImplMultiRefNonContainerNPL createImplMultiRefNonContainerNPL();

  /**
   * Returns a new object of class '<em>Impl Contained Element NPL</em>'. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return a new object of class '<em>Impl Contained Element NPL</em>'.
   * @generated
   */
  ImplContainedElementNPL createImplContainedElementNPL();

  /**
   * Returns the package supported by this factory. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @return the package supported by this factory.
   * @generated
   */
  model4Package getmodel4Package();

} // model4Factory
