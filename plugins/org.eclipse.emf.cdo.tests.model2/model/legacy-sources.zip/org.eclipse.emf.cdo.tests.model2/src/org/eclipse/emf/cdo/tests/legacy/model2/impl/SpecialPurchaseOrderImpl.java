/**
 * <copyright>
 * </copyright>
 *
 * $Id: SpecialPurchaseOrderImpl.java,v 1.2 2008/09/18 12:56:55 estepper Exp $
 */
package org.eclipse.emf.cdo.tests.legacy.model2.impl;

import org.eclipse.emf.cdo.tests.legacy.model1.impl.PurchaseOrderImpl;
import org.eclipse.emf.cdo.tests.legacy.model2.Model2Package;
import org.eclipse.emf.cdo.tests.model1.Address;
import org.eclipse.emf.cdo.tests.model2.SpecialPurchaseOrder;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Special Purchase Order</b></em>'. <!--
 * end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 * <li>{@link org.eclipse.emf.cdo.tests.legacy.model2.impl.SpecialPurchaseOrderImpl#getDiscountCode <em>Discount Code
 * </em>}</li>
 * <li>{@link org.eclipse.emf.cdo.tests.legacy.model2.impl.SpecialPurchaseOrderImpl#getShippingAddress <em>Shipping
 * Address</em>}</li>
 * </ul>
 * </p>
 * 
 * @generated
 */
public class SpecialPurchaseOrderImpl extends PurchaseOrderImpl implements SpecialPurchaseOrder
{
  /**
   * The default value of the '{@link #getDiscountCode() <em>Discount Code</em>}' attribute. <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * 
   * @see #getDiscountCode()
   * @generated
   * @ordered
   */
  protected static final String DISCOUNT_CODE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getDiscountCode() <em>Discount Code</em>}' attribute. <!-- begin-user-doc --> <!--
   * end-user-doc -->
   * 
   * @see #getDiscountCode()
   * @generated
   * @ordered
   */
  protected String discountCode = DISCOUNT_CODE_EDEFAULT;

  /**
   * The cached value of the '{@link #getShippingAddress() <em>Shipping Address</em>}' containment reference. <!--
   * begin-user-doc --> <!-- end-user-doc -->
   * 
   * @see #getShippingAddress()
   * @generated
   * @ordered
   */
  protected Address shippingAddress;

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  protected SpecialPurchaseOrderImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return Model2Package.Literals.SPECIAL_PURCHASE_ORDER;
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  public String getDiscountCode()
  {
    eFireRead(Model2Package.SPECIAL_PURCHASE_ORDER__DISCOUNT_CODE);
    return discountCode;
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  public void setDiscountCode(String newDiscountCode)
  {
    eFireWrite(Model2Package.SPECIAL_PURCHASE_ORDER__DISCOUNT_CODE);
    String oldDiscountCode = discountCode;
    discountCode = newDiscountCode;
    if (eNotificationRequired())
    {
      eNotify(new ENotificationImpl(this, Notification.SET, Model2Package.SPECIAL_PURCHASE_ORDER__DISCOUNT_CODE,
          oldDiscountCode, discountCode));
    }
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  public Address getShippingAddress()
  {
    eFireRead(Model2Package.SPECIAL_PURCHASE_ORDER__SHIPPING_ADDRESS);
    return shippingAddress;
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  public NotificationChain basicSetShippingAddress(Address newShippingAddress, NotificationChain msgs)
  {
    eFireWrite(Model2Package.SPECIAL_PURCHASE_ORDER__SHIPPING_ADDRESS);
    Address oldShippingAddress = shippingAddress;
    shippingAddress = newShippingAddress;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
          Model2Package.SPECIAL_PURCHASE_ORDER__SHIPPING_ADDRESS, oldShippingAddress, newShippingAddress);
      if (msgs == null)
      {
        msgs = notification;
      }
      else
      {
        msgs.add(notification);
      }
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  public void setShippingAddress(Address newShippingAddress)
  {
    eFireWrite(Model2Package.SPECIAL_PURCHASE_ORDER__SHIPPING_ADDRESS);
    if (newShippingAddress != shippingAddress)
    {
      NotificationChain msgs = null;
      if (shippingAddress != null)
      {
        msgs = ((InternalEObject)shippingAddress).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
            - Model2Package.SPECIAL_PURCHASE_ORDER__SHIPPING_ADDRESS, null, msgs);
      }
      if (newShippingAddress != null)
      {
        msgs = ((InternalEObject)newShippingAddress).eInverseAdd(this, EOPPOSITE_FEATURE_BASE
            - Model2Package.SPECIAL_PURCHASE_ORDER__SHIPPING_ADDRESS, null, msgs);
      }
      msgs = basicSetShippingAddress(newShippingAddress, msgs);
      if (msgs != null)
      {
        msgs.dispatch();
      }
    }
    else if (eNotificationRequired())
    {
      eNotify(new ENotificationImpl(this, Notification.SET, Model2Package.SPECIAL_PURCHASE_ORDER__SHIPPING_ADDRESS,
          newShippingAddress, newShippingAddress));
    }
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
    case Model2Package.SPECIAL_PURCHASE_ORDER__SHIPPING_ADDRESS:
      return basicSetShippingAddress(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
    case Model2Package.SPECIAL_PURCHASE_ORDER__DISCOUNT_CODE:
      return getDiscountCode();
    case Model2Package.SPECIAL_PURCHASE_ORDER__SHIPPING_ADDRESS:
      return getShippingAddress();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
    case Model2Package.SPECIAL_PURCHASE_ORDER__DISCOUNT_CODE:
      setDiscountCode((String)newValue);
      return;
    case Model2Package.SPECIAL_PURCHASE_ORDER__SHIPPING_ADDRESS:
      setShippingAddress((Address)newValue);
      return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
    case Model2Package.SPECIAL_PURCHASE_ORDER__DISCOUNT_CODE:
      setDiscountCode(DISCOUNT_CODE_EDEFAULT);
      return;
    case Model2Package.SPECIAL_PURCHASE_ORDER__SHIPPING_ADDRESS:
      setShippingAddress((Address)null);
      return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
    case Model2Package.SPECIAL_PURCHASE_ORDER__DISCOUNT_CODE:
      return DISCOUNT_CODE_EDEFAULT == null ? discountCode != null : !DISCOUNT_CODE_EDEFAULT.equals(discountCode);
    case Model2Package.SPECIAL_PURCHASE_ORDER__SHIPPING_ADDRESS:
      return shippingAddress != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy())
    {
      return super.toString();
    }

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (discountCode: ");
    result.append(discountCode);
    result.append(')');
    return result.toString();
  }

} // SpecialPurchaseOrderImpl
